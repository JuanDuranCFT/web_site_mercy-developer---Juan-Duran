import { Component } from '@angular/core';

@Component({
  selector: 'app-ubicanos',
  templateUrl: './ubicanos.component.html',
})
export class UbicanosComponent {
  nombre = '';
  apellido = '';
  mensajeEnviado = false;

  enviarMensaje() {
    console.log(`Mensaje enviado por: ${this.nombre} ${this.apellido}`);
    this.mensajeEnviado = true;
  }
}
